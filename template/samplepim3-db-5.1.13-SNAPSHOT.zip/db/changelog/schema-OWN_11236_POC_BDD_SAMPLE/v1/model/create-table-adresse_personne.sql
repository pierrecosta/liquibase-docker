CREATE TABLE ADRESSE_PERSONNE (
  adresse_personne_id int not null,
  country varchar2(100) not null,
  city varchar2(100) not null,
  details varchar2(100),
  CONSTRAINT adresse_personne_pk PRIMARY KEY (adresse_personne_id)
);

CREATE SEQUENCE SQ_ADRESSE_PERSONNE_ID;