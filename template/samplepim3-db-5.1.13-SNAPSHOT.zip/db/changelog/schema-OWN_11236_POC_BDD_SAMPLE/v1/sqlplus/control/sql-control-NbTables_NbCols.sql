WHENEVER SQLERROR EXIT SQL.SQLCODE;
SPOOL sqlplus_NbTables_NbCols.log;
SELECT 'Actual schema is ' || USERNAME || '.' FROM USER_USERS;

-- NB table in Schema
SELECT 'Schema has ' || COUNT(*) || ' tables.' FROM USER_TABLES;

-- Nb Tables with more 256 Columns
SELECT 'Table ' ||TABLE_NAME || ' has too much columns : '|| NB_COLS || ' (max allowed is 2) !' FROM
  (
    SELECT
      TABLE_NAME,
      COUNT(COLUMN_NAME) AS NB_COLS
    FROM USER_TAB_COLS 
    GROUP BY TABLE_NAME
  )
WHERE NB_COLS > 2;
SPOOL OFF;
EXIT 0;
