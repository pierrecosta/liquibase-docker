INSERT INTO PERSONNE_PHYSIQUE ( personne_physique_id, pph_nom_usage, pph_prenom) VALUES (sq_personne_physique_id.NEXTVAL, 'Vix', 'Aida1');
INSERT INTO PERSONNE_PHYSIQUE ( personne_physique_id, pph_nom_usage, pph_prenom) VALUES (sq_personne_physique_id.NEXTVAL, 'Vix', 'Aida2');
INSERT INTO PERSONNE_PHYSIQUE ( personne_physique_id, pph_nom_usage, pph_prenom) VALUES (sq_personne_physique_id.NEXTVAL, 'Vix', 'Aida3');
INSERT INTO PERSONNE_PHYSIQUE ( personne_physique_id, pph_nom_usage, pph_prenom) VALUES (sq_personne_physique_id.NEXTVAL, 'Vix', 'Aida4');
INSERT INTO PERSONNE_PHYSIQUE ( personne_physique_id, pph_nom_usage, pph_prenom) VALUES (sq_personne_physique_id.NEXTVAL, 'Vix', 'Aida5');