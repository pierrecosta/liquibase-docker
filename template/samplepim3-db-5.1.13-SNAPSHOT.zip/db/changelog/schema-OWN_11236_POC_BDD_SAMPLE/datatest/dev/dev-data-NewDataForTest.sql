INSERT INTO PERSONNE_PHYSIQUE ( personne_physique_id, pph_nom_usage, pph_prenom) VALUES (sq_personne_physique_id.NEXTVAL, 'Vix', 'Jenny1');
INSERT INTO PERSONNE_PHYSIQUE ( personne_physique_id, pph_nom_usage, pph_prenom) VALUES (sq_personne_physique_id.NEXTVAL, 'Vix', 'Jenny2');
INSERT INTO PERSONNE_PHYSIQUE ( personne_physique_id, pph_nom_usage, pph_prenom) VALUES (sq_personne_physique_id.NEXTVAL, 'Vix', 'Jenny3');
INSERT INTO PERSONNE_PHYSIQUE ( personne_physique_id, pph_nom_usage, pph_prenom) VALUES (sq_personne_physique_id.NEXTVAL, 'Vix', 'Jenny4');
INSERT INTO PERSONNE_PHYSIQUE ( personne_physique_id, pph_nom_usage, pph_prenom) VALUES (sq_personne_physique_id.NEXTVAL, 'Vix', 'Jenny5');