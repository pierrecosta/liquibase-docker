  -- Create table structure
CREATE TABLE PERSONNE_PHYSIQUE (
  personne_physique_id int not null,
  pph_nom_usage varchar2(100) not null,
  pph_prenom varchar2(100) not null,
  pph_autres_prenoms varchar2(100),
  CONSTRAINT personne_physique_pk PRIMARY KEY (personne_physique_id)
);

  -- Create Sequence
CREATE SEQUENCE SQ_PERSONNE_PHYSIQUE_ID;
