SPOOL CREATE_PKG_MANAGE_GRANTS.out
WHENEVER OSERROR EXIT FAILURE
WHENEVER SQLERROR EXIT SQL.SQLCODE

CREATE OR REPLACE PACKAGE PKG_MANAGE_GRANTS
IS
    PROCEDURE prc_process_grants_tables(p_grantee VARCHAR2, p_granter VARCHAR2, p_grant VARCHAR2);
END PKG_MANAGE_GRANTS;
/

CREATE OR REPLACE PACKAGE BODY PKG_MANAGE_GRANTS
IS  
    PROCEDURE prc_process_grants_tables(p_grantee VARCHAR2, p_granter VARCHAR2, p_grant VARCHAR2)
    IS
    BEGIN
      FOR x IN
          (
          select table_name from user_tables 
          )
      LOOP
          BEGIN
              EXECUTE IMMEDIATE 'GRANT ' || p_grant || ' ON ' || x.table_name || ' TO ' || p_grantee;
          EXCEPTION
              WHEN OTHERS THEN NULL;
          END;
      END LOOP;
    END prc_process_grants_tables;

END PKG_MANAGE_GRANTS;
/

SHOW ERRORS;

SPOOL OFF;
EXIT;