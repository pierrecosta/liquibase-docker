SPOOL DROP_PKG_MANAGE_ADRESSE.out
WHENEVER OSERROR EXIT FAILURE
WHENEVER SQLERROR EXIT SQL.SQLCODE

--------------------------------------------------------
--  DDL for Package PKG_MANAGE_ADRESSE
--------------------------------------------------------

CREATE OR REPLACE PACKAGE PKG_MANAGE_ADRESSE AS
 PROCEDURE UpdateVilleToLorient (id_addr IN integer);
 PROCEDURE DeleteWhenNoCountry;
 PROCEDURE UpdateVilleToNull;
END PKG_MANAGE_ADRESSE;
/

--------------------------------------------------------
--  DDL for Package Body POC_TOOLS
--------------------------------------------------------

CREATE OR REPLACE PACKAGE BODY PKG_MANAGE_ADRESSE IS
PROCEDURE UpdateVilleToLorient
     (id_addr IN integer)
     AS
       BEGIN
         UPDATE TBL_ADDRESS
         SET VILLE = 'LORIENT'  WHERE HJID > 2000 and HJID < 3000;
END UpdateVilleToLorient;

PROCEDURE UpdateVilleToNull
     IS
       BEGIN
         UPDATE TBL_ADDRESS
         SET VILLE = ''  WHERE VILLE='LORIENT';
END UpdateVilleToNull;
/

SHOW ERRORS;

SPOOL OFF;
EXIT;

