SPOOL CREATE_FUNC_DECRYPT_AES_BIS.out
WHENEVER OSERROR EXIT FAILURE
WHENEVER SQLERROR EXIT SQL.SQLCODE

CREATE OR REPLACE FUNCTION DECRYPT_AES_BIS(
               encryptedStr IN VARCHAR,dkey IN VARCHAR
         )
              RETURN VARCHAR
         IS
              fcount VARCHAR(128);
         BEGIN
              select UTL_RAW.CAST_TO_VARCHAR2(
                      SYS.DBMS_CRYPTO.DECRYPT(
                          utl_encode.base64_decode(utl_raw.cast_to_raw(encryptedStr)),
                                 SYS.DBMS_CRYPTO.ENCRYPT_AES + SYS.DBMS_CRYPTO.CHAIN_CFB  + SYS.DBMS_CRYPTO.PAD_PKCS5,
                                      UTL_RAW.CAST_TO_RAW(dkey),
                                          UTL_RAW.CAST_TO_RAW('BNPCredit0Click2016'))) INTO fcount from dual;
            RETURN fcount;
         END;
		 /
SHOW ERRORS;
SPOOL OFF;
EXIT;
