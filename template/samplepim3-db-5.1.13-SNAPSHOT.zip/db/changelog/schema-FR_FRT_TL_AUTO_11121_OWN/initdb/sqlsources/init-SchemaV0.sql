  -- Create schema to be iso PROD
CREATE SCHEMA ${synonymA} AUTHORIZATION DBA;
