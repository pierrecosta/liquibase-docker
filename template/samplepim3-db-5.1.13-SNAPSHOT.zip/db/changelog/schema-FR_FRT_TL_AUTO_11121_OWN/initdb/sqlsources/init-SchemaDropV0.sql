  -- Drop schema to cleanDB
DROP SCHEMA ${synonymA} CASCADE;

